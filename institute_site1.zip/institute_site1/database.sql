
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS `institute_db`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `institute_db`;


CREATE TABLE IF NOT EXISTS `registrations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name`   VARCHAR(120) NOT NULL,
  `email`       VARCHAR(160) NOT NULL,
  `phone`       VARCHAR(50)  NOT NULL,
  `department`  VARCHAR(120) NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reg_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS `contacts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `full_name`   VARCHAR(120) NOT NULL,
  `email`       VARCHAR(160) NOT NULL,
  `message`     MEDIUMTEXT   NOT NULL,
  `ip`          VARCHAR(64)  NULL,
  `user_agent`  VARCHAR(512) NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_contact_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS `schedule` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `day_of_week` ENUM('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday') NOT NULL,
  `time_slot`   VARCHAR(50)  NOT NULL,  
  `course_name` VARCHAR(120) NOT NULL,   
  `hall`        VARCHAR(60)  NOT NULL,   
  `section`     VARCHAR(80)  NOT NULL DEFAULT 'General', 
  PRIMARY KEY (`id`),
  KEY `idx_day` (`day_of_week`),
  KEY `idx_section` (`section`),
  KEY `idx_day_time` (`day_of_week`,`time_slot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `schedule`
  ADD COLUMN IF NOT EXISTS `section` VARCHAR(80) NOT NULL DEFAULT 'General';
ALTER TABLE `schedule`
  ADD INDEX IF NOT EXISTS `idx_section` (`section`),
  ADD INDEX IF NOT EXISTS `idx_day_time` (`day_of_week`,`time_slot`);


CREATE TABLE IF NOT EXISTS `news` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`      VARCHAR(200) NOT NULL,
  `body`       MEDIUMTEXT   NOT NULL,
  `image_path` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_news_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE OR REPLACE VIEW `vw_schedule_ordered` AS
SELECT
  s.*,
  FIELD(s.day_of_week,'Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday') AS day_order
FROM schedule s;




DELETE FROM schedule
WHERE (section IN ('Computer 3','Computer 4 / Pro','Computer 4 / Web','Computer 5 / Web',
                   'Reception 3','Reception 5','Oil 5','Web / 4 / 5','Pro / 1'))
  AND (day_of_week IN ('Saturday','Sunday','Monday','Tuesday'));


INSERT INTO schedule (day_of_week,time_slot,course_name,hall,section) VALUES
('Saturday','09:00-10:30','English','Hall-4','Computer 3'),
('Saturday','10:45-12:15','Web concept-1','Lab-1','Web / 4 / 5'),
('Saturday','09:00-10:30','JAVA-1','Lab-1','Pro / 1'),
('Saturday','12:30-14:00','Refinery','Hall-5','Computer 3'),
('Saturday','14:15-15:45','Mass Transfer','Hall-5','Pro / 1');

INSERT INTO schedule (day_of_week,time_slot,course_name,hall,section) VALUES
('Sunday','09:00-10:30','JAVA-1','Hall-1','Pro / 1'),
('Sunday','10:45-12:15','ASP.NET (MFC)','Lab-3','Web / 4 / 5'),
('Sunday','12:30-14:00','PPO','Hall-5','Computer 3'),
('Sunday','14:15-15:45','Power Point','Hall-2','Web / 4 / 5');


INSERT INTO schedule (day_of_week,time_slot,course_name,hall,section) VALUES
('Monday','09:00-10:30','English','Hall-1','Computer 3'),
('Monday','10:45-12:15','JAVA-2','Hall-2','Computer 4 / Pro'),
('Monday','12:30-14:00','CCNA','Lab-3','Computer 5 / Web'),
('Monday','14:15-15:45','Reception Basics','Hall-1','Reception 3');


INSERT INTO schedule (day_of_week,time_slot,course_name,hall,section) VALUES
('Tuesday','09:00-10:30','Oil Refinery Intro','Hall-5','Oil 5'),
('Tuesday','10:45-12:15','Web concept-2','Lab-2','Computer 4 / Web'),
('Tuesday','12:30-14:00','IS','Hall-1','Computer 3');


INSERT INTO news (title,body,image_path) VALUES
('Orientation Week','Welcome to all new students! Sessions start Saturday.',''),
('Programming Contest','Join the ICPC-style contest next month.','');
