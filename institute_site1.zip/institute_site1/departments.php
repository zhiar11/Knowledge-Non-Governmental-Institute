<?php
require __DIR__ . '/config/init.php';

$departments = [
    'computer' => [
        'title_en' => 'Computer Department',
        'title_ku' => 'بەشی کۆمپیوتەر',
        'sections' => [
            'Computer 3',
            'Computer 4 / Pro',
            'Computer 4 / Web',
            'Computer 5 / Web',
            'Web / 4 / 5',
            'Pro / 1'
        ],
    ],
    'admin' => [
        'title_en' => 'Administration & Reception',
        'title_ku' => 'بەشی کارگێری و ریسپشنی',
        'sections' => [
            'Reception 3',
            'Reception 5',
            'Administration',
        ],
    ],
    'oil' => [
        'title_en' => 'Oil Department',
        'title_ku' => 'بەشی نەوت',
        'sections' => [
            'Oil 5',
        ],
    ],
];

$deptStats = [];
foreach ($departments as $key => $info) {
    if (empty($info['sections'])) {
        $deptStats[$key] = 0;
        continue;
    }
    $placeholders = rtrim(str_repeat('?,', count($info['sections'])), ',');
    $sql = "SELECT COUNT(*) AS c FROM schedule WHERE section IN ($placeholders)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($info['sections']);
    $deptStats[$key] = (int) ($stmt->fetch()['c'] ?? 0);
}

include __DIR__ . '/header.php';
?>
<html lang="ku" dir="rtl">
<div class="container">

  <div class="card">
    <div class="hero-mini">
      <div>
        <h2>بەشەکانی پەیمانگا</h2>
        <p class="muted">
          لێرە دەتوانیت زانیاری گشتی بۆ هەر بەشێک ببینیت، کە وەک کۆمپیوتەر، کارگێری و ریسپشنی،
          و نەوت. هەروەها دەتوانیت ببینیت کە چەن وانەی هەفتانە بۆ هەر بەشێک دانراوە.
        </p>
      </div>
      <div class="notice" style="max-width:280px">
        🔄 هەر کات خشتەکە نوێ بکەیتەوە، ئەم ژمارانەش خۆکارانە نوێ دەبنەوە.
      </div>
    </div>
  </div>


  <div class="dept-grid">


    <?php
    $comp = $departments['computer'];
    $compCount = $deptStats['computer'];
    ?>
    <div class="card dept-card dept-computer">
      <div class="dept-header">
        <div class="dept-icon">💻</div>
        <div>
          <h3><?php echo htmlspecialchars($comp['title_ku']); ?> • <?php echo htmlspecialchars($comp['title_en']); ?></h3>
          <p class="muted">
             و هەموو توانای IT نوێ. خوێندکارانی ئەم بەشە زۆر نزیکن بە بازاڕی کار.
          </p>
        </div>
      </div>

      <ul class="dept-list">
        <li>کۆرسەکان: JAVA, Web concept, ASP.NET, CCNA, Flutter, MySql …</li>
        <li>بەشەکان:
          <?php echo htmlspecialchars(implode(' ، ', $comp['sections'])); ?>
        </li>
        <li>تاقیگە و لابۆراتواری تایبەت بۆ پرۆگرامکردن و شێوەپێدانی پڕۆژەکان.</li>
        <li>نرخەکەی لە 1,800,000 داشکێنراوە بۆ 1,200,000</li>
      </ul>

      <div class="dept-footer">
        <a class="btn" href="schedule.php">بینینی خشتەی کارەکان</a>
        <span class="badge">
          📚 <?php echo $compCount; ?> وانەکان لە خشتەی هەفتانەدا
        </span>
      </div>
    </div>

    <?php
    $adm = $departments['admin'];
    $admCount = $deptStats['admin'];
    ?>
    <div class="card dept-card dept-admin">
      <div class="dept-header">
        <div class="dept-icon">📋</div>
        <div>
          <h3><?php echo htmlspecialchars($adm['title_ku']); ?> • <?php echo htmlspecialchars($adm['title_en']); ?></h3>
          <p class="muted">
           بەڕێوەبردنی ئۆفیس، بنەماکانی ژمێریاری، پەیوەندیکردن، و خزمەتگوزاری بە رێزمانی
            ئیداری و ریسپشنی. گونجاو بۆ ئەوانەی کە دەتەوێن کار بکەن لە دامەزراوەکان و کۆمپانیاکان.
          </p>
        </div>
      </div>

      <ul class="dept-list">
        <li>کۆرسەکان:بنەماکانی ژمێریاری، پەیوەندیکردن، نەرمەکاڵای ئۆفیس، چاودێری کڕیار ...</li>
        <li>بەشەکان:
          <?php echo htmlspecialchars(implode(' ، ', $adm['sections'])); ?>
        </li>
        <li>پراکتیكی: تاقیگەی ریسپشنی و دۆخی ڕاستەقینەی کار لە ڕێگەی ڕووداو و ڕۆڵلێدان.</li>
        <li>نرخەکەی لە 1,800,000 داشکێنراوە بۆ 1,100,000</li>
      </ul>

      <div class="dept-footer">
        <a class="btn-soft" href="schedule.php">بینینی خشتەی کارەکان</a>
        <span class="badge">
          🗂 <?php echo $admCount; ?>وانەکان لە خشتەی هەفتانەدا
        </span>
      </div>
    </div>

  
    <?php
    $oil = $departments['oil'];
    $oilCount = $deptStats['oil'];
    ?>
    <div class="card dept-card dept-oil">
      <div class="dept-header">
        <div class="dept-icon">⛽</div>
        <div>
          <h3><?php echo htmlspecialchars($oil['title_ku']); ?> • <?php echo htmlspecialchars($oil['title_en']); ?></h3>
          <p class="muted">
            درەنگەکان و بنەمای زانستی بەشی نەوت، پالایش، و سیستەمە صنعتییەکان.
            بەشێکی گرنگ بۆ بازاڕی کار لە هەرێمی کوردستان.
          </p>
        </div>
      </div>

      <ul class="dept-list">
        <li>کۆرسەکان:پاڵاوگە، گواستنەوەی بارستەیی، میکانیکی شلە ...</li>
        <li>بەشەکان:
          <?php echo htmlspecialchars(implode(' ، ', $oil['sections'])); ?>
        </li>
        <li>ڕووکارەکان: سەرەخۆش بە وانەی پرۆژە و سەرەدانی خانەخوێنی ناو سنوور.</li>
        <li>نرخەکەی لە 2,500,000 داشکێنراوە بۆ 1,300,000</li>
      </ul>

      <div class="dept-footer">
        <a class="btn-soft" href="schedule.php">>بینینی خشتەی کارەکان</a>
        <span class="badge">
          🛢 <?php echo $oilCount; ?> وانەکان لە خشتەی هەفتانەدا
        </span>
      </div>
    </div>

  </div>

</div>

<?php include __DIR__ . '/footer.php'; ?>
