<?php require __DIR__ . '/config/init.php'; ?>
<?php include __DIR__ . '/header.php'; ?>

<section class="hero">
  <video autoplay muted loop playsinline>
    <source src="<?php echo BASE; ?>/assets/video/hero.mp4" type="video/mp4">
  </video>
  <div class="overlay container">
    <span class="badge">پێشوازی • بەخێربێت </span>
    <h1>فێربە، بنیات بنێ و درەوشاوەبە ✨</h1>
    <p>
      🎓 خوێندنی IT، کارگێری و نەوت بە سیستەمی نوێ و لابۆراتواری کاربەری.
      دەتوانیت بە خێرایی خۆت تۆمار بکەیت و ببیتە پارچەیەک لە پەیمانگاکە.
    </p>
    <a class="btn" href="<?php echo BASE; ?>/register.php">ئێستا ناوت تۆمار بکە</a>
  </div>
</section>
<section class="container">
  <h2></h2>
  <div class="grid">
  <?php
  $stories = $pdo->query("SELECT * FROM testimonials ORDER BY created_at DESC LIMIT 3")->fetchAll();
  foreach ($stories as $s):
  ?>
    <div class="card">
      <img src="uploads/<?php echo htmlspecialchars($s['photo']); ?>" width="100%" style="border-radius:12px;">
      <h3><?php echo htmlspecialchars($s['student_name']); ?> (<?php echo htmlspecialchars($s['year']); ?>)</h3>
      <p><?php echo nl2br(htmlspecialchars($s['message'])); ?></p>
    </div>
  <?php endforeach; ?>
  </div>
</section>



    <div class="card">
      <h3>بۆچی ئێمە هەڵدەبژێریت؟</h3>
      <ul>
        <li>مەنهەجی نوێ و سەردەمیانە.</li>
        <li>تاقیگەی دەستی و ڕاهێنەری زۆر باش.</li>
        <li> کۆبونەوەی ئێواران بۆ خوێندکارانی کارمەند.</li>
      </ul>
     
    </div>
  </div>

  <div class="grid" style="margin-top:18px">
    <div class="card">
      <h3>پێویستت بە پلانی تەواوی هەفتانە هەیە؟</h3>
      <p>لە خشتەی کارلێکدا بەپێی ڕۆژ و بەشەکان بگەڕێ.</p>
      <a class="btn" href="<?php echo BASE; ?>/schedule.php">بینینی خشتەی هەفتانە</a>
    </div>

    <div class="card">
      <h3>بەشەکان و بەرنامەکان</h3>
      <p>بەشی کۆمپیوتەر، کارگێڕی، و نەوت لە ئاستە جیاوازەکاندا.</p>
      <a class="btn-soft" href="<?php echo BASE; ?>/departments.php">بینین بەشەکان</a>
    </div>

    <div class="card">
      <h3>هەواڵ و گەلەری</h3>
      <p>بینینی چالاکییەکانی ئەم دواییە، چیرۆکی سەرکەوتنەکان، و میدیاکانی پەیمانگا.</p>
      <a class="btn-soft" style="margin-left:8px" href="<?php echo BASE; ?>/news.php">هەواڵەکان</a>
      <a class="btn-soft" href="<?php echo BASE; ?>/gallery.php">ونەکان</a>
    </div>
  </div>

  <div class="card home-testimonials">
    <h3> 🎓 سۆزەکانی سەرکەوتنی خوێندکاران</h3>
    <p class="muted">
      وتەی خوێندکارانی سەرکەوتوودا کە چۆن پەیمانگاکە یارمەتیدانیان کردووە بۆ داهاتوویان.
    </p>
    <div class="testimonials-grid">
      <div class="testimonial-card">
        <div class="testimonial-head">
          <div class="testimonial-avatar">A</div>
          <div>
            <div class="testimonial-name">Aram H.</div>
            <div class="testimonial-role">Computer 4 / Web</div>
          </div>
        </div>
        <p>
          “لە پەیمانگای نۆلج فێری پڕۆگرامکردنی ڕاستەقینە بووم. پڕۆژەکانمان و لابۆراتوارەکان
          بەهۆی مامۆستاکانەوە زۆر بەسوود بوون.”
        </p>
      </div>

      <div class="testimonial-card">
        <div class="testimonial-head">
          <div class="testimonial-avatar">S</div>
          <div>
            <div class="testimonial-name">Shno M.</div>
            <div class="testimonial-role">Reception 3</div>
          </div>
        </div>
        <p>
          “وانەکانی کارگێری و ریسپشنی فێرکرد کە چۆن لە دۆخی کاردا بە پشتڕاستی پێشوازی میوان بکەم.
          ئێستا لە هوتێلێک کاردەکەم.”
        </p>
      </div>

      <div class="testimonial-card">
        <div class="testimonial-head">
          <div class="testimonial-avatar">D</div>
          <div>
            <div class="testimonial-name">Diyar A.</div>
            <div class="testimonial-role">Oil 5</div>
          </div>
        </div>
        <p>
          “بەشی نەوت یارمەتیم کرد هەست بە کەرتی پالایش و سیستەمە صنعتییەکان بکەم.
          تئۆری و کاربەری تێکەڵ بوو.”
        </p>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
