<?php require __DIR__ . '/config/init.php'; ?>
<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$single = null;
if ($id > 0) {
  $s = $pdo->prepare("SELECT * FROM news WHERE id=?");
  $s->execute([$id]);
  $single = $s->fetch();
}
include __DIR__ . '/header.php';
?>
<div class="container">
  <?php if($single): ?>
    <div class="card">
      <h2 style="margin:0 0 10px"><?php echo h($single['title']); ?></h2>
      <div style="color:var(--muted)"><?php echo h($single['created_at']); ?></div>
      <?php if($single['image_path']): ?>
        <img src="<?php echo BASE . '/' . h($single['image_path']); ?>" style="width:100%;max-height:420px;object-fit:cover;border-radius:14px;margin:12px 0">
      <?php endif; ?>
      <div><?php echo nl2br(h($single['body'])); ?></div>
    </div>
    <div style="margin-top:14px"><a class="btn" href="<?php echo BASE; ?>/news.php">←گەڕانەوە بۆ لیستەکە</a></div>
  <?php else: ?>
    <h2>هەواڵ و چالاکییەکان</h2>
    <?php
      $items = $pdo->query("SELECT id,title,image_path,created_at FROM news ORDER BY created_at DESC")->fetchAll();
      if(!$items) echo '<p class="notice">No news yet.</p>';
    ?>
    <div class="grid">
      <?php foreach($items as $n): ?>
        <a class="card" href="?id=<?php echo (int)$n['id']; ?>">
          <?php if($n['image_path']): ?>
            <img src="<?php echo BASE . '/' . h($n['image_path']); ?>" alt="" style="width:100%;height:160px;object-fit:cover;border-radius:12px;margin-bottom:10px">
          <?php endif; ?>
          <strong><?php echo h($n['title']); ?></strong>
          <div style="color:var(--muted);font-size:12px"><?php echo h($n['created_at']); ?></div>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>
