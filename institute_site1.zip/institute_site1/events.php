<?php
require __DIR__ . '/config/init.php';
$events = $pdo->query("SELECT * FROM events ORDER BY event_date ASC")->fetchAll();
include __DIR__ . '/header.php';
?>
<div class="container">
  <div class="card hero-mini">
    <h2>📅 Upcoming Events & Timeline</h2>
    <p class="muted">Seminars, exams, and workshops throughout the year.</p>
  </div>
  <div class="timeline">
    <?php foreach ($events as $e): ?>
      <div class="timeline-item">
        <div class="dot"></div>
        <div class="content">
          <h3><?php echo htmlspecialchars($e['title']); ?></h3>
          <p class="muted"><?php echo date('F j, Y', strtotime($e['event_date'])); ?> — <?php echo htmlspecialchars($e['location']); ?></p>
          <p><?php echo nl2br(htmlspecialchars($e['description'])); ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
