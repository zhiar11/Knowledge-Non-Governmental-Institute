<?php
require __DIR__ . '/config/init.php';

// CSRF + rate limit setup
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
$csrf_token = $_SESSION['csrf_token'];

$sent  = false;
$errors = [];
$MIN_SECONDS_BETWEEN_SUBMITS = 15;
$now = time();
$last_submit = $_SESSION['last_contact_submit'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Support normal POST and JS fetch(JSON)
    $isJson = (strpos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false);
    if ($isJson) {
        $raw  = file_get_contents('php://input');
        $data = json_decode($raw, true) ?: [];
        $_POST = array_merge($_POST, $data);
    }

    // CSRF check
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], (string)$token)) {
        $errors[] = 'Invalid form submission.';
    }

    // Rate limit
    if ($now - $last_submit < $MIN_SECONDS_BETWEEN_SUBMITS) {
        $errors[] = 'Please wait a few seconds before sending another message.';
    }

    // Honeypot (anti-bot)
    if (!empty($_POST['website'] ?? '')) {
        // Bot filled the hidden field – pretend success but do nothing
        $sent = true;
    } else {
        // Real data
        $name    = trim((string)($_POST['name'] ?? ''));
        $email   = trim((string)($_POST['email'] ?? ''));
        $message = trim((string)($_POST['message'] ?? ''));

        if ($name === '' || $email === '' || $message === '') {
            $errors[] = 'Please fill all fields.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        } elseif (strlen($message) > 5000) {
            $errors[] = 'Message is too long.';
        }

        if (empty($errors)) {
            try {
                // Save to DB
                $stmt = $pdo->prepare(
                    "INSERT INTO contacts (full_name, email, message, ip, user_agent)
                     VALUES (?, ?, ?, ?, ?)"
                );
                $ip = $_SERVER['REMOTE_ADDR'] ?? null;
                $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 512);
                $stmt->execute([$name, $email, $message, $ip, $ua]);

                $sent = true;
                $_SESSION['last_contact_submit'] = $now;

                // Send email (using PHP mail())
                $to      = 'zhyerfaraj342@gmail.com';
                $subject = 'New contact message from website';
                $body    = "Name: $name\nEmail: $email\nIP: $ip\n\nMessage:\n$message\n";
                $headers = "From: " . $email . "\r\nReply-To: " . $email . "\r\n";

                @mail($to, $subject, $body, $headers);

            } catch (Exception $ex) {
                $errors[] = 'Server error. Please try again later.';
            }
        }
    }

    // If request came from JS fetch (AJAX), return JSON
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || $isJson) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => $sent && empty($errors),
            'errors'  => $errors,
            'message' => $sent ? 'Message sent. We will reply soon.' : null
        ]);
        exit;
    }
}
?>

<?php include __DIR__ . '/header.php'; ?>

<html lang="ku" dir="rtl">
<div class="container">
  <h2>پەیوەندیمان پێوە بکەن</h2>

  <div class="columns">
    <div class="card" id="contact-card">
      <?php if ($sent): ?>
        <div class="card" style="border-color:#2e7c4f;background:#10231c;color:#c1ffd9">
          ✅ پەیامێک نێردراوە. بەم زووانە وەڵام دەدەینەوە.
        </div>
      <?php else: ?>
        <?php if (!empty($errors)): ?>
          <div class="card" style="border-color:#80333b;background:#26151a;color:#ffd7de">
            <?php foreach ($errors as $er) echo '<div>'. h($er) .'</div>'; ?>
          </div>
        <?php endif; ?>

        <form id="contactForm" method="post" action="" style="display:grid;gap:10px" novalidate>
          <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">

          <!-- Honeypot field (hidden for humans) -->
          <label style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;">
            ئەمە بە بەتاڵی بهێڵەرەوە
            <input type="text" name="website" tabindex="-1" autocomplete="off">
          </label>

          <label>ناو
            <input name="name" class="input" required value="<?php echo h($_POST['name'] ?? ''); ?>">
          </label>

          <label>ئیمەیڵ
            <input type="email" name="email" class="input" required value="<?php echo h($_POST['email'] ?? ''); ?>">
          </label>

          <label>نامەکەت
            <textarea name="message" class="input" required><?php echo h($_POST['message'] ?? ''); ?></textarea>
          </label>

          <div style="display:flex;gap:10px;align-items:center">
            <button class="btn" type="submit">نامە بنێرە</button>
            <div id="formStatus" role="status" aria-live="polite" style="color:var(--muted);"></div>
          </div>
        </form>

        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">
          <a class="btn" href="tel:+964770105008">Call +964 770 105 008</a>
          <a class="btn" href="mailto:zhyerfaraj342@gmail.com">ئیمەیڵمان بۆ بنێرە</a>
          <a class="btn" href="<?php echo BASE; ?>/location.php">بینینی نەخشە</a>
        </div>
      <?php endif; ?>
    </div>

    <div class="card">
      <h3>پەیوەندی و ئۆفیس</h3>
      <p class="notice">
        Phone: +964 770 105 008 - +964 750 105 008<br>
        Email: knowledge.saidsadq@gmail.com
      </p>
      <h3>کاتی ئۆفیس</h3>
      <p>Sat–Thu: 3:00–7:45</p>

      <h3 style="margin-top:12px">تایبەتمەندیەتی</h3>
      <p style="color:var(--muted)">
       ئێمە نامە و زانیاری پەیوەندیکردنت هەڵدەگرین بۆ وەڵامدانەوە. ئێمە داتاکانتان بە ئاشکرا هاوبەش ناکەین.
      </p>
    </div>
  </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>

<script>
(function(){
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', async function(e){
    e.preventDefault();
    const name    = form.elements['name'].value.trim();
    const email   = form.elements['email'].value.trim();
    const message = form.elements['message'].value.trim();
    const website = form.elements['website'].value.trim(); // honeypot

    const statusEl = document.getElementById('formStatus');
    statusEl.textContent = '';

    if (!name || !email || !message) {
      statusEl.textContent = 'Please fill all fields.';
      return;
    }
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(email)) {
      statusEl.textContent = 'Please enter a valid email address.';
      return;
    }
    if (website) {
      form.reset();
      statusEl.textContent = 'Message sent. We will reply soon.';
      return;
    }

    const payload = {
      name,
      email,
      message,
      csrf_token: form.elements['csrf_token'].value
    };

    try {
      statusEl.textContent = 'Sending...';
      const resp = await fetch(window.location.href, {
        method: 'POST',
        headers: {
          'Content-Type':'application/json',
          'X-Requested-With':'XMLHttpRequest'
        },
        body: JSON.stringify(payload),
        credentials: 'same-origin'
      });
      const data = await resp.json();
      if (data.success) {
        statusEl.textContent = data.message || 'Message sent. We will reply soon.';
        form.reset();
      } else {
        statusEl.textContent = (data.errors && data.errors.join('; ')) || 'Failed to send.';
      }
    } catch (err) {
      console.error(err);
      statusEl.textContent = 'Network error. Falling back to page submit...';
      form.removeEventListener('submit', arguments.callee);
      form.submit();
    }
  });
})();
</script>
