<button id="toTop" title="Back to top">↑</button>
<script>
const btn = document.getElementById("toTop");
window.addEventListener("scroll",()=>btn.style.display = window.scrollY>300 ? "flex":"none");
btn.addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"}));
</script>
<footer class="footer container">
  © <?php echo date('Y'); ?> Knowledge Institute •
  <a href="<?php echo BASE; ?>/contact.php">Contact us</a>
</footer>

<button id="toTop" title="Back to top" style="display:none;">↑</button>


<script src="<?php echo BASE; ?>/assets/js/app.js"></script>
</body>
</html>
