<?php require __DIR__ . '/../config/init.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }

$days = ['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday'];

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['mode']) && $_POST['mode']==='save'){
  $id = (int)($_POST['id'] ?? 0);
  $day = trim($_POST['day'] ?? '');
  $time = trim($_POST['time'] ?? '');
  $course = trim($_POST['course'] ?? '');
  $hall = trim($_POST['hall'] ?? '');
  $section = trim($_POST['section'] ?? '');
  if($day && $time && $course && $hall && $section){
    if($id>0){
      $pdo->prepare("UPDATE schedule SET day_of_week=?,time_slot=?,course_name=?,hall=?,section=? WHERE id=?")
          ->execute([$day,$time,$course,$hall,$section,$id]);
    }else{
      $pdo->prepare("INSERT INTO schedule(day_of_week,time_slot,course_name,hall,section) VALUES(?,?,?,?,?)")
          ->execute([$day,$time,$course,$hall,$section]);
    }
  }
  header('Location: schedule.php'); exit;
}


if(isset($_GET['delete'])){
  $pdo->prepare("DELETE FROM schedule WHERE id=?")->execute([(int)$_GET['delete']]);
  header('Location: schedule.php'); exit;
}


$importMsg='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['mode']) && $_POST['mode']==='import'){
  if(!empty($_FILES['csv']['tmp_name'])){
    $f = fopen($_FILES['csv']['tmp_name'], 'r');
    $count=0;
    while(($row=fgetcsv($f))!==false){
      if(count($row)<5) continue;
      [$d,$t,$c,$h,$s] = array_map('trim',$row);
      if(!$d||!$t||!$c||!$h||!$s) continue;
      $pdo->prepare("INSERT INTO schedule(day_of_week,time_slot,course_name,hall,section) VALUES(?,?,?,?,?)")
          ->execute([$d,$t,$c,$h,$s]); $count++;
    }
    fclose($f);
    $importMsg = "Imported $count rows.";
  } else { $importMsg = "No file."; }
}


$filter = trim($_GET['section'] ?? '');
$sections = $pdo->query("SELECT DISTINCT section FROM schedule ORDER BY section")->fetchAll(PDO::FETCH_COLUMN);

$orderDays = "FIELD(day_of_week,'Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday'), section, time_slot";
if ($filter !== '') {
  $st = $pdo->prepare("SELECT * FROM schedule WHERE section=? ORDER BY $orderDays");
  $st->execute([$filter]);
} else {
  $st = $pdo->query("SELECT * FROM schedule ORDER BY $orderDays");
}
$rows = $st->fetchAll();


$edit=null;
if(!empty($_GET['edit'])){
  $s = $pdo->prepare("SELECT * FROM schedule WHERE id=?");
  $s->execute([(int)$_GET['edit']]);
  $edit = $s->fetch();
}

include __DIR__ . '/../header.php';
?>
<div class="container">
  <h2>Manage Schedule</h2>

  <div class="card chips">
    <a class="chip <?php echo $filter===''?'active':''; ?>" href="schedule.php">هەموو</a>
    <?php foreach($sections as $sec): ?>
      <a class="chip <?php echo $filter===$sec?'active':''; ?>" href="?section=<?php echo urlencode($sec); ?>"><?php echo h($sec); ?></a>
    <?php endforeach; ?>
  </div>

  <?php if($importMsg): ?><div class="card" style="margin-top:10px"><?php echo h($importMsg); ?></div><?php endif; ?>

  <div class="columns" style="margin-top:12px">
    <div class="card">
      <h3><?php echo $edit?'Edit row':'Add row'; ?></h3>
      <form method="post" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
        <input type="hidden" name="mode" value="save">
        <input type="hidden" name="id" value="<?php echo $edit?(int)$edit['id']:0; ?>">
        <label>ڕۆژ
          <select name="day" class="select" required>
            <?php foreach($days as $d): ?><option value="<?php echo $d; ?>" <?php echo ($edit && $edit['day_of_week']===$d)?'selected':''; ?>><?php echo $d; ?></option><?php endforeach; ?>
          </select>
        </label>
        <label>کات <input name="time" class="input" required placeholder="09:00-10:30" value="<?php echo $edit? h($edit['time_slot']) : ''; ?>"></label>
        <label>کۆرس <input name="course" class="input" required placeholder="English, JAVA-1..." value="<?php echo $edit? h($edit['course_name']) : ''; ?>"></label>
        <label>هۆڵ/لاب <input name="hall" class="input" required placeholder="Hall-1, Lab-2..." value="<?php echo $edit? h($edit['hall']) : ''; ?>"></label>
        <label>بەش <input name="section" class="input" required placeholder="Web / 4 / 5, Pro / 1, Computer 3..." value="<?php echo $edit? h($edit['section']) : ''; ?>"></label>
        <div style="grid-column:1/-1"><button class="btn" type="submit">Save</button></div>
      </form>
    </div>

    <div class="card">
      <h3>Bulk import (CSV)</h3>
      <p class="notice">Columns: day_of_week,time_slot,course_name,hall,section</p>
      <form method="post" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center">
        <input type="hidden" name="mode" value="import">
        <input type="file" name="csv" accept=".csv" class="input" required>
        <button class="btn" type="submit">Import</button>
      </form>
    </div>
  </div>

  <div class="card" style="margin-top:14px">
    <table class="table">
      <thead><tr><th>ID</th><th>ڕۆژ</th><th>کات</th><th>کۆرس</th><th>هۆڵ/لاب</th><th>بەش</th><th>کار</th></tr></thead>
      <tbody>
        <?php if(!$rows): ?><tr><td colspan="7" style="color:var(--muted)">هیچ وانەیەک نییە.</td></tr>
        <?php else: foreach($rows as $r): ?>
        <tr>
          <td><?php echo (int)$r['id']; ?></td>
          <td><?php echo h($r['day_of_week']); ?></td>
          <td><?php echo h($r['time_slot']); ?></td>
          <td><?php echo h($r['course_name']); ?></td>
          <td><?php echo h($r['hall']); ?></td>
          <td><?php echo h($r['section']); ?></td>
          <td>
            <a href="?edit=<?php echo (int)$r['id']; ?>">Edit</a> |
            <a href="?delete=<?php echo (int)$r['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../footer.php'; ?>
