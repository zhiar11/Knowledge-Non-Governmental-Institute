<?php require __DIR__ . '/../config/init.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }

$edit=null;
if(!empty($_GET['edit'])){
  $s=$pdo->prepare("SELECT * FROM news WHERE id=?"); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch();
}

/* Save (create/update) */
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=(int)($_POST['id']??0);
  $title=trim($_POST['title']??''); $body=trim($_POST['body']??'');
  $imagePath=$edit['image_path']??null;

  if(!empty($_FILES['image']['tmp_name'])){
    $dir=__DIR__ . '/../assets/uploads/';
    if(!is_dir($dir)) @mkdir($dir,0777,true);
    $okTypes=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $type=mime_content_type($_FILES['image']['tmp_name']);
    if(isset($okTypes[$type])){
      $ext=$okTypes[$type]; $name='news_'.time().'_'.bin2hex(random_bytes(4)).'.'.$ext;
      move_uploaded_file($_FILES['image']['tmp_name'],$dir.$name);
      $imagePath='assets/uploads/'.$name;
    } else { $msg='Image type not allowed.'; }
  }

  if($title && $body){
    if($id>0){
      $pdo->prepare("UPDATE news SET title=?, body=?, image_path=? WHERE id=?")
          ->execute([$title,$body,$imagePath,$id]);
      $msg='Updated.';
    } else {
      $pdo->prepare("INSERT INTO news(title,body,image_path) VALUES(?,?,?)")
          ->execute([$title,$body,$imagePath]);
      $msg='Created.';
    }
    $edit=null;
  } else { $msg='Fill title and body.'; }
}

/* list */
$items=$pdo->query("SELECT id,title,created_at FROM news ORDER BY created_at DESC")->fetchAll();

include __DIR__ . '/../header.php';
?>
<div class="container">
  <h2>Manage News & Activities</h2>
  <?php if($msg): ?><div class="card"><?php echo h($msg); ?></div><?php endif; ?>

  <div class="columns">
    <div class="card">
      <h3><?php echo $edit?'Edit':'Add'; ?> post</h3>
      <form method="post" enctype="multipart/form-data" style="display:grid;gap:10px">
        <input type="hidden" name="id" value="<?php echo $edit?(int)$edit['id']:0; ?>">
        <label>Title <input name="title" class="input" required value="<?php echo $edit? h($edit['title']) : ''; ?>"></label>
        <label>Body <textarea name="body" class="input" required><?php echo $edit? h($edit['body']) : ''; ?></textarea></label>
        <label>Image (jpg/png/webp) <input type="file" name="image" accept="image/*" class="input"></label>
        <?php if($edit && $edit['image_path']): ?>
          <img src="<?php echo BASE . '/' . h($edit['image_path']); ?>" style="max-width:240px;border-radius:12px">
        <?php endif; ?>
        <button class="btn" type="submit">Save</button>
      </form>
    </div>

    <div class="card">
      <h3>All posts</h3>
      <table class="table">
        <thead><tr><th>ID</th><th>Title</th><th>When</th><th>Actions</th></tr></thead>
        <tbody>
          <?php foreach($items as $n): ?>
            <tr>
              <td><?php echo (int)$n['id']; ?></td>
              <td><?php echo h($n['title']); ?></td>
              <td><?php echo h($n['created_at']); ?></td>
              <td>
                <a href="?edit=<?php echo (int)$n['id']; ?>">Edit</a> |
                <a href="news_delete.php?id=<?php echo (int)$n['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../footer.php'; ?>
