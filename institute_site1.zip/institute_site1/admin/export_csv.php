<?php require __DIR__ . '/../config/init.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=registrations.csv');
$out=fopen('php://output','w');
fputcsv($out,['id','full_name','email','phone','department','created_at']);
$stmt=$pdo->query("SELECT id,full_name,email,phone,department,created_at FROM registrations ORDER BY id ASC");
foreach($stmt as $row){ fputcsv($out,$row); }
fclose($out);
