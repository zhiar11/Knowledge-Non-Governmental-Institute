<?php
require __DIR__ . '/../config/init.php';

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
  header('Location: login.php');
  exit;
}

$message = '';
$edit = null;

if (isset($_GET['delete'])) {
  $id = (int)$_GET['delete'];
  $stmt = $pdo->prepare("DELETE FROM events WHERE id=?");
  $stmt->execute([$id]);
  $message = 'Event deleted.';
}

if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  $stmt = $pdo->prepare("SELECT * FROM events WHERE id=?");
  $stmt->execute([$id]);
  $edit = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)($_POST['id'] ?? 0);
  $title = trim($_POST['title'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $event_date = $_POST['event_date'] ?? '';
  $event_time = trim($_POST['event_time'] ?? '');
  $location = trim($_POST['location'] ?? '');
  $type = $_POST['type'] ?? 'other';

  if ($title && $description && $event_date) {
    if ($id > 0) {
      $stmt = $pdo->prepare(
        "UPDATE events SET title=?,description=?,event_date=?,event_time=?,location=?,type=? WHERE id=?"
      );
      $stmt->execute([$title,$description,$event_date,$event_time,$location,$type,$id]);
      $message = 'Event updated.';
    } else {
      $stmt = $pdo->prepare(
        "INSERT INTO events(title,description,event_date,event_time,location,type)
         VALUES(?,?,?,?,?,?)"
      );
      $stmt->execute([$title,$description,$event_date,$event_time,$location,$type]);
      $message = 'Event created.';
    }
    $edit = null;
  } else {
    $message = 'Please fill title, description, and date.';
  }
}

$events = $pdo->query(
  "SELECT * FROM events ORDER BY event_date DESC, id DESC"
)->fetchAll();

include __DIR__ . '/../header.php';
?>
<div class="container">
  <div class="card">
    <h2>Manage Events</h2>
    <p class="muted">Add seminars, exams, and workshops. They appear on the public Events page.</p>
    <?php if($message): ?>
      <div class="notice"><?php echo h($message); ?></div>
    <?php endif; ?>

    <form method="post" class="card"
          style="margin-top:14px;display:grid;gap:10px;max-width:720px">
      <input type="hidden" name="id" value="<?php echo $edit ? (int)$edit['id'] : 0; ?>">

      <label>Title
        <input class="input" name="title" required
               value="<?php echo h($edit['title'] ?? ''); ?>">
      </label>

      <label>Date
        <input class="input" type="date" name="event_date" required
               value="<?php echo h($edit['event_date'] ?? ''); ?>">
      </label>

      <label>Time
        <input class="input" name="event_time" placeholder="09:00-11:00"
               value="<?php echo h($edit['event_time'] ?? ''); ?>">
      </label>

      <label>Location
        <input class="input" name="location" placeholder="Hall-3 / Lab-1"
               value="<?php echo h($edit['location'] ?? ''); ?>">
      </label>

      <label>Type
        <select name="type" class="select">
          <?php
          $types = ['seminar'=>'Seminar','exam'=>'Exam','workshop'=>'Workshop','other'=>'Other'];
          $currentType = $edit['type'] ?? 'other';
          foreach($types as $val=>$label){
            $sel = $val === $currentType ? 'selected' : '';
            echo '<option value="'.h($val).'" '.$sel.'>'.h($label).'</option>';
          }
          ?>
        </select>
      </label>

      <label>Description
        <textarea name="description" class="input" rows="4"><?php
          echo h($edit['description'] ?? '');
        ?></textarea>
      </label>

      <div style="display:flex;gap:10px">
        <button class="btn" type="submit">
          <?php echo $edit ? 'Save changes' : 'Add event'; ?>
        </button>
        <?php if($edit): ?>
          <a class="btn-soft" href="events.php">Cancel edit</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <div class="card" style="margin-top:20px">
    <h3>All events</h3>
    <table class="table">
      <thead>
        <tr><th>Title</th><th>Date</th><th>Type</th><th>Location</th><th></th></tr>
      </thead>
      <tbody>
        <?php foreach($events as $e): ?>
          <tr>
            <td><?php echo h($e['title']); ?></td>
            <td><?php echo h($e['event_date']); ?></td>
            <td><?php echo h($e['type']); ?></td>
            <td><?php echo h($e['location']); ?></td>
            <td>
              <a href="events.php?edit=<?php echo (int)$e['id']; ?>">Edit</a> •
              <a href="events.php?delete=<?php echo (int)$e['id']; ?>"
                 onclick="return confirm('Delete this event?');">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../footer.php'; ?>
