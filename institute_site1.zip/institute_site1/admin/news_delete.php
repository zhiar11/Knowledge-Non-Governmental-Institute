<?php require __DIR__ . '/../config/init.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
$id=(int)($_GET['id']??0);
if($id>0){ $pdo->prepare("DELETE FROM news WHERE id=?")->execute([$id]); }
header('Location: news.php');
