<?php require __DIR__ . '/../config/init.php'; require __DIR__ . '/../config/auth.php';
if(isset($_SESSION['admin']) && $_SESSION['admin']===true){ header('Location: dashboard.php'); exit; }
$err=''; if($_SERVER['REQUEST_METHOD']==='POST'){
  $u=$_POST['username']??''; $p=$_POST['password']??'';
  if($u===ADMIN_USER && $p===ADMIN_PASS){ $_SESSION['admin']=true; header('Location: dashboard.php'); exit; }
  else { $err='Invalid credentials.'; }
}
include __DIR__ . '/../header.php';
?>
<div class="container">
  <h2>Admin Login</h2>
  <?php if($err): ?><div class="card" style="border-color:#80333b;background:#26151a;color:#ffd7de"><?php echo h($err); ?></div><?php endif; ?>
  <form method="post" class="card" style="display:grid;gap:10px;max-width:420px">
    <label>Username <input name="username" class="input"></label>
    <label>Password <input type="password" name="password" class="input"></label>
    <button class="btn" type="submit">Login</button>
  </form>
</div>
<?php include __DIR__ . '/../footer.php'; ?>
