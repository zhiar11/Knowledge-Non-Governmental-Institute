<?php require __DIR__ . '/../config/init.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }

$stats = [
  'registrations' => (int)$pdo->query("SELECT COUNT(*) c FROM registrations")->fetch()['c'],
  'messages'      => (int)$pdo->query("SELECT COUNT(*) c FROM contacts")->fetch()['c'],
  'news'          => (int)$pdo->query("SELECT COUNT(*) c FROM news")->fetch()['c'],
];
$latest = $pdo->query("SELECT id,full_name,email,phone,department,created_at FROM registrations ORDER BY created_at DESC LIMIT 10")->fetchAll();
$latestMsgs = $pdo->query("SELECT id,full_name,email,message,created_at FROM contacts ORDER BY created_at DESC LIMIT 5")->fetchAll();
$latestNews = $pdo->query("SELECT id,title,created_at FROM news ORDER BY created_at DESC LIMIT 5")->fetchAll();

include __DIR__ . '/../header.php';
?>
<div class="container">
  <div class="grid">
    <div class="card"><h3>Total Registrations</h3><div class="kpi"><?php echo number_format($stats['registrations']); ?></div></div>
    <div class="card"><h3>Messages</h3><div class="kpi"><?php echo number_format($stats['messages']); ?></div></div>
    <div class="card"><h3>News posts</h3><div class="kpi"><?php echo number_format($stats['news']); ?></div></div>
    <div class="card">
      <h3>Quick links</h3>
      <a class="btn" href="schedule.php">Manage Schedule</a>
      <a class="btn" style="margin-right:8px" href="news.php">Manage News</a>
      <a class="btn" style="margin-right:8px;background:linear-gradient(90deg,#ff8a8a,#ffcd8b)" href="export_csv.php">Export CSV</a>
      <a class="btn" style="margin-right:8px;background:linear-gradient(90deg,#ff8a8a,#ffcd8b)" href="logout.php">Logout</a>
    </div>
  </div>

  <div class="columns" style="margin-top:16px">
    <div class="card">
      <h3>Latest registrations</h3>
      <table class="table">
        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Department</th><th>When</th></tr></thead>
        <tbody><?php foreach($latest as $r): ?>
          <tr><td><?php echo (int)$r['id']; ?></td><td><?php echo h($r['full_name']); ?></td>
          <td><?php echo h($r['email']); ?></td><td><?php echo h($r['phone']); ?></td>
          <td><?php echo h($r['department']); ?></td><td><?php echo h($r['created_at']); ?></td></tr>
        <?php endforeach; ?></tbody>
      </table>
    </div>
    <div class="card">
      <h3>Latest messages</h3>
      <table class="table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Message</th><th>When</th></tr></thead>
        <tbody><?php foreach($latestMsgs as $m): ?>
          <tr><td><?php echo (int)$m['id']; ?></td><td><?php echo h($m['full_name']); ?></td>
          <td><?php echo h($m['email']); ?></td><td><?php echo nl2br(h($m['message'])); ?></td>
          <td><?php echo h($m['created_at']); ?></td></tr>
        <?php endforeach; ?></tbody>
      </table>
      <h3 style="margin-top:14px">Latest news</h3>
      <ul><?php foreach($latestNews as $n) echo '<li><a href="news.php?edit='.(int)$n['id'].'">'.h($n['title']).'</a> — '.h($n['created_at']).'</li>'; ?></ul>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../footer.php'; ?>
