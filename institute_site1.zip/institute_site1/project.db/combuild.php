


<?php
include ('conn.php');

?>



<!DOCTYPE html>
<html lang="en">
<head>

  <title>computer build</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body{
        background-color: rgb(1, 9, 29);
        padding: 20px;
        font-family: Arial;
    }
 </style>
</head>
<body>
  <!---------------hedar---------------------------------------------------------->
<style>
    nav{
     
     border-radius: 4px;
     box-shadow: 0px 0px 0px 0px ;
    
    padding: 0px;
    }
  </style>
  <style>
   li,a,button{
    font-family:"montserrat", sans-serif;
    font-size: 16px;
    font-weight: 500;
    color: #edf0ed;
    display: flex;
    justify-content: space-between;
    align-items: center;

   }
  </style>
 
  <div class="bg-dark ">
  <nav class="navbar navbar-expand-lg  navbar-dark">
    <div class="container ">
     
 
      <img src="https://cdna.pcpartpicker.com/static/forever/img/pcpp-logo.svg" class="nav__logo--full" alt="PCPartPicker">
     
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 nav-light">
          <li class="nav-item">
            <a class="nav-link  " aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pcbuilder.php">Pc builder</a>
            <a class="nav-link" href="about.php">about</a>
            <a class="nav-link text-bg-warning" href="combuild.php">Completed Builds</a>
            <a class="nav-link  "href="login.php">Login</a>  
            <a class="nav-link  "href="register.php">register</a>             
          </li>  
        </nav>
     </div>
     <!-------------------------poto sell-------------------------------------------->
    
    
    <div class="row m-2 justify-content-center">
<?php 
$query =mysqli_query($conn ,"SELECT * FROM `builds` ");
while($row = mysqli_fetch_assoc($query)){

?>
      <div class="card m-2 p-2 border-0 radius-10"style="width: 19rem;">

      <a target="_blank" href="img/<?php echo $row['Image'];  ?>">
        <img src="img/<?php echo $row['Image'];  ?>" alt="jdsufh"class="card-img-top" >
</a>
        <div class="card-body">
          <h6 clss="card-title "><?php echo $row['Creation_date']; ?></h6>
          <p class="card-text h6 "><?php echo $row['created_by']; ?></h6></p>
          <p style="font-size:12px " class="card-text ">price: <?php echo $row['price'].'$'; ?></p>
      
        </div>
        <div class="card-footer">
        <a href="see morr.php?postid=<?php echo $row['ID']; ?>"type="button  " class="btn btn-warning w-100 ">View</a>
        </div>
       </div>
       <?php 
              }
       ?>
        </div>
      
     
    
   <!--------------------------------footer--------------------------------------------------->
    
   <footer class="mt-5 p-4  text-white text-center pb-4">
  
    <div class="container text-center text-md-left">
      <div class="row text-center text-md-left">
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <img src="img/pc.png" class="float-start" alt="Paris" width="30" height="30" >
 
  
        <p>
          <a href="#" style=" text-decoration :none"class="text-white h6 " >PICK PARTS</a>
      
          <a href="#" style=" text-decoration :none"class="text-white h6 " >BUILD YOUR PC.</a>
       
          <a href="#" style=" text-decoration :none"class="text-white h6 " >COMPARE AND SHARE.</a>
        </p>
        <!------------------------- bashy dwam----------------------------------->
      </div>
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3 ">
        <p>
          <a href="#" style=" text-decoration :none"class="text-warning h6 " > CATEGORIES</a>
        </p>
        <p>
          <a href="#" style="text-decoration :none" > PC Builder </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Build Guides </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Completed Build</a>
        </p>
      </div>
  
  <!-------------------------bashy seyam ----------------------------------->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
       
        <p>
          <a href="#" style=" text-decoration :none"class="text-warning h5 " > INFORMATION</a>
        </p>
        <p>
          <a href="#" style="text-decoration :none" > PC Builder </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Build Guides </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Completed Build</a>
        </p>
      </div>
  
  <!----------------------------bashy chwaram ------------------------------------------>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <p>
          <a href="#" style="text-decoration :none"class="text-warning h5" > COMPANY </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none" > PC Builder </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Build Guides </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Completed Build</a>
        </p>
      </div>
  <!-------------------------------------kota ----------------------------------------------->
   <hr>
     </div>
      </div>
      <style>
        .row1{content: "";
    display: table;
    clear: both;
          
        }
       
      </style>
      <div class="containermt">
       
      <div class="container text-center ">
      
      <a class="nav-link "href="#">
        <img src="IMG/instagram (1).png" class="float-r" alt="Paris" width="20" height="20">
        <img src="img/facebook (3).png" class="float-r" alt="Paris" width="20" height="20">
        <img src="IMG/telegram.png" class="float-r" alt="Paris" width="20" height="20">
       <img src="img/pc7.png" class="float-r" alt="Paris" width="20" height="20">
     </a>
  
    </div>
    </div>
    <a class="nav-link "href="#">
    <p class="text-bg-darck text-center">©2024 nwekar. All rights reserved</p>
  </a>
   
      </footer>

</body>
</html>