<!DOCTYPE html>
<html >
<head >
   <title> about </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

 
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core
@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNf
EXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/boots
trap@5.2.2/dist/js/bootstrap.min.js" integrity=
"sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

  
</head>
<body>


<!---------------hedar---------------------------------------------------------->



  <style>
  body{
      background-color: rgb(1, 9, 29);
      padding: 20px;
          font-family: Arial;}
    nav{
      background-color: dark;
     border-radius: 4px;
     box-shadow: 0px 0px 0px 0px ;

    padding: 0px;
    }
  </style>
  <style>
   li,a,button{
    font-family:"montserrat", sans-serif;
    font-size: 16px;
    font-weight: 500;
    color: #edf0ed;
    display: flex;
    justify-content: space-between;
    align-items: center;

   }
  </style>

  <div class="bg-dark ">
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
     
      <img src="https://cdna.pcpartpicker.com/static/forever/img/pcpp-logo.svg" class="nav__logo--full" alt="PCPartPicker">
      
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0 nav-light">
          <li class="nav-item">
            <a class="nav-link " aria-current="page" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pcbuilder.php">Pc builder</a>
            <a class="nav-link active text-bg-warning" href="about.php">about</a>
            <a class="nav-link" href="combuild.php">Completed Builds</a>
           
            <a class="nav-link active "href="login.php">Login</a>    
            <a class="nav-link active "href="register.php">register</a>  
            
          </li>

             
         </nav>
    </div></div>
    <!---------------------------------------------------->
    
           
   
   
 

    <h4>  <div class="alert alert-warning m-4 text-center ">
    about
      </div></h4>
    <!----------------- rasmakan zanyary lasaryan -------------------------------------------->
    
    <div class="alert alert-warning m-4  p-5  text-black rounded text-center ">
<h1 > ABSTRACT</h1>
  <p>PCPartPicker—is a comparison shopping website that can help save 
  your  time and money as you wade into the world of PC building,
     Maybe you're tired of the bloatware that comes on pre-built PCs. you can build your dream pc ,
      in this site and get your own parts of the pc and our site is working online , 
      when ever you want or where ever you are don't hesitate make your self at home , 
       The site will also automatically filter out components that are incompatible with choices you have already 
       made or issue a warning when necessary.<br> If you're not sure what to put into your build, there are two places to 
       start. Build guides are designed by the PCPartPicker team to encompass 
       certain tiers of PC builds, they were selected for that particular machine. As useful as PCPartPicker can be, it’s ultimately just a tool. Like any other tool, it helps when you use it correctly and have some general knowledge before starting ,
        thanks to chose us too be your guider.</p>
</div>
<div class="alert alert-warning m-4 text-center">
  <strong>this project is made by!<br></strong>  nwekar arf
  <br>
  <a class="nav-link "href="https://www.facebook.com/taqananew1?mibextid=LQQJ4d">
  <img src="img/nwekar.jpg" class="float-r" alt="Paris" width="70" height="70">
<br>
  <img src="img/new.png" class="float-r" alt="Paris" width="30" height="30">
 </a>
  

</div>
  <!--------------------------------footer--------------------------------------------------->


  <footer class="mt-5 p-4  text-white text-center pb-4">
  
    <div class="container text-center text-md-left">
      <div class="row text-center text-md-left">
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <img src="IMG/pc.png" class="float-start" alt="Paris" width="30" height="30" >
  <style>
    p{  text-transform: capitalize;}
  </style>
  
        <p>
          <a href="#" style=" text-decoration :none"class="text-white h6 " >PICK PARTS</a>
        </p>
        <p>
          <a href="#" style=" text-decoration :none"class="text-white h6 " >BUILD YOUR PC.</a>
        </p>
        <p>
          <a href="#" style=" text-decoration :none"class="text-white h6 " >COMPARE AND SHARE.</a>
        </p>
        <!------------------------- bashy dwam----------------------------------->
      </div>
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3 ">
        <p>
          <a href="#" style=" text-decoration :none"class="text-warning h6 " > CATEGORIES</a>
        </p>
        <p>
          <a href="#" style="text-decoration :none" > PC Builder </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Build Guides </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Completed Build</a>
        </p>
      </div>
  
  <!-------------------------bashy seyam ----------------------------------->
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
       
        <p>
          <a href="#" style=" text-decoration :none"class="text-warning h6 " > INFORMATION</a>
        </p>
        <p>
          <a href="#" style="text-decoration :none" > PC Builder </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Build Guides </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Completed Build</a>
        </p>
      </div>
  
  <!----------------------------bashy chwaram ------------------------------------------>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <p>
          <a href="#" style="text-decoration :none"class="text-warning h6" > COMPANY </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none" > PC Builder </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Build Guides </a>
        </p>
        <p>
          <a href="#" style="text-decoration :none"> Completed Build</a>
        </p>
      </div>
  <!-------------------------------------kota ----------------------------------------------->
   <hr>
     </div>
      </div>
      <style>
        .row1{content: "";
    display: table;
    clear: both;
          
        }
       
      </style>
      <div class="containermt">
       
      <div class="container text-center ">
      
      <a class="nav-link "href="#">
        <img src="IMG/instagram (1).png" class="float-r" alt="Paris" width="20" height="20">
        <img src="img/facebook (3).png" class="float-r" alt="Paris" width="20" height="20">
        <img src="IMG/telegram.png" class="float-r" alt="Paris" width="20" height="20">
       <img src="img/pc7.png" class="float-r" alt="Paris" width="20" height="20">
     </a>
  
    </div>
    </div>
    <a class="nav-link "href="#">
    <p class="text-bg-darck text-center">©2024 nwekar. All rights reserved</p>
  </a>
   
      </footer>
  
   
    </body>
    </html>
    
      
  
  
  
  

    
      
     






