<?php

require __DIR__ . '/config/init.php';


$days = ['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday'];


$EXTRA_SECTIONS = [
  'Computer 3',
  'Computer 4 / Pro',
  'Computer 4 / Web',
  'Computer 5 / Web',
  'Reception 3',
  'Reception 5',
  'Oil 5',
];


$sectionsFromDb = $pdo->query("SELECT DISTINCT section FROM schedule ORDER BY section")
                      ->fetchAll(PDO::FETCH_COLUMN);


$sections = $EXTRA_SECTIONS;
foreach ($sectionsFromDb as $s) {
  if (!in_array($s, $sections, true)) $sections[] = $s;
}


if (isset($_GET['ajax'])) {
  header('Content-Type: text/html; charset=utf-8');

  $day = (string)($_GET['day'] ?? '');
  $sec = (string)($_GET['section'] ?? '');

  if (!in_array($day, $days, true) || !in_array($sec, $sections, true)) {
    http_response_code(400);
    echo '<div class="card" style="color:var(--muted)">Invalid filters.</div>';
    exit;
  }

  $stmt = $pdo->prepare("SELECT time_slot, course_name, hall, section
                         FROM schedule
                         WHERE day_of_week=? AND section=?
                         ORDER BY time_slot");
  $stmt->execute([$day, $sec]);
  $rows = $stmt->fetchAll();
  ?>
  <div class="card">
    <h3 style="margin:0 0 8px"><?php echo h($day); ?> • <?php echo h($sec); ?></h3>
    <table class="table">
      <thead>
        <tr>
          <th>کات</th>
          <th>کۆرس</th>
          <th>هۆڵ/لاب</th>
          <th>بەش</th>
        </tr>
      </thead>
      <tbody>
        <?php if(!$rows): ?>
          <tr><td colspan="4" style="color:var(--muted)">هیچ وانەیەک نییە بۆ ئەم هەڵبژاردەیانە.</td></tr>
        <?php else: foreach($rows as $r): ?>
          <tr>
            <td class="slot"><?php echo h($r['time_slot']); ?></td>
            <td><?php echo h($r['course_name']); ?></td>
            <td class="hall"><?php echo h($r['hall']); ?></td>
            <td><?php echo h($r['section']); ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
  <?php
  exit;
}


$initialDay = (string)($_GET['day'] ?? '');
$initialSec = (string)($_GET['section'] ?? '');
$hasInitial = in_array($initialDay, $days, true) && in_array($initialSec, $sections, true);

include __DIR__ . '/header.php';
?>

<style>
.filters{display:grid;grid-template-columns:1fr 1fr auto;gap:10px}
@media (max-width:800px){.filters{grid-template-columns:1fr}}
.filters .select{height:44px}
.filters .btn{height:44px;font-size:15px}
.header-pill{background:linear-gradient(180deg,var(--card),var(--bg-soft));
  border:1px solid var(--stroke);border-radius:18px;padding:14px 16px;margin-bottom:14px;
  display:flex;align-items:center;justify-content:space-between;gap:12px}
.header-pill .title{font-size:26px;font-weight:900}
.hint{color:var(--muted)}
</style>

<div class="container">
  <div class="header-pill">
    <div class="title">خشتەی وانەکان</div>
 
  </div>

  <div class="card">
    <form id="filterForm" class="filters" onsubmit="return false;">
      <label>
        <div style="margin-bottom:6px;color:var(--muted);font-weight:800"> ڕۆژی هەفتە</div>
        <select id="daySel" class="select" required>
          <option value="" disabled selected>هەڵبژاردنی ڕۆژ...</option>
          <?php foreach($days as $d): ?>
            <option value="<?php echo h($d); ?>" <?php echo $initialDay===$d?'selected':''; ?>>
              <?php echo h($d); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>
        <div style="margin-bottom:6px;color:var(--muted);font-weight:800">بەش </div>
        <select id="secSel" class="select" required>
          <option value="" disabled selected>هەڵبژاردنی بەش...</option>
          <?php foreach($sections as $s): ?>
            <option value="<?php echo h($s); ?>" <?php echo $initialSec===$s?'selected':''; ?>>
              <?php echo h($s); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>

      <div style="display:flex;align-items:flex-end">
        <button id="showBtn" class="btn" type="button" style="width:100%">پیشاندانی وانەکان</button>
      </div>
    </form>
  </div>

  <div id="results" style="margin-top:14px">
    <?php
    if ($hasInitial) {
      $stmt = $pdo->prepare("SELECT time_slot,course_name,hall,section
                             FROM schedule
                             WHERE day_of_week=? AND section=?
                             ORDER BY time_slot");
      $stmt->execute([$initialDay,$initialSec]);
      $rows = $stmt->fetchAll();
      ?>
      <div class="card">
        <h3 style="margin:0 0 8px"><?php echo h($initialDay); ?> • <?php echo h($initialSec); ?></h3>
        <table class="table">
          <thead><tr><th>کات</th><th>کۆرس</th><th>هۆڵ/لاب</th><th>بەش</th></tr></thead>
          <tbody>
            <?php if(!$rows): ?>
              <tr><td colspan="4" style="color:var(--muted)">هیچ وانەیەک نییە.</td></tr>
            <?php else: foreach($rows as $r): ?>
              <tr>
                <td class="slot"><?php echo h($r['time_slot']); ?></td>
                <td><?php echo h($r['course_name']); ?></td>
                <td class="hall"><?php echo h($r['hall']); ?></td>
                <td><?php echo h($r['section']); ?></td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
      <?php
    } 
    ?>
  </div>
</div>

<script>
(function(){
  const daySel = document.getElementById('daySel');
  const secSel = document.getElementById('secSel');
  const showBtn = document.getElementById('showBtn');
  const results = document.getElementById('results');

  function enableBtn(){ showBtn.disabled = !(daySel.value && secSel.value); }

  async function fetchLessons(){
    if (!daySel.value || !secSel.value) return;
    const url = new URL(window.location.href);
    url.searchParams.set('day', daySel.value);
    url.searchParams.set('section', secSel.value);
    window.history.replaceState({}, '', url.toString());

    results.innerHTML = '<div class="card" style="color:var(--muted)">Loading…</div>';
    try{
      const r = await fetch(`<?php echo BASE; ?>/schedule.php?ajax=1&day=${encodeURIComponent(daySel.value)}&section=${encodeURIComponent(secSel.value)}`, {credentials:'same-origin'});
      results.innerHTML = await r.text();
    }catch(e){
      results.innerHTML = '<div class="card" style="color:#ffd7de;background:#26151a;border-color:#80333b">Network error.</div>';
    }
  }

  daySel.addEventListener('change', enableBtn);
  secSel.addEventListener('change', enableBtn);
  showBtn.addEventListener('click', fetchLessons);
  enableBtn();
})();
</script>

<?php include __DIR__ . '/footer.php'; ?>
