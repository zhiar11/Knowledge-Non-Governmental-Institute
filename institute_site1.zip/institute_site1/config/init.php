<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/app.php';
require_once __DIR__ . '/db.php';

function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }


try {
  $hasSection = $pdo->query("SHOW COLUMNS FROM `schedule` LIKE 'section'")->fetch();
  if (!$hasSection) {
    $pdo->exec("ALTER TABLE `schedule` ADD COLUMN `section` VARCHAR(80) NOT NULL DEFAULT 'General' AFTER `hall`");
    $pdo->exec("CREATE INDEX `idx_section` ON `schedule`(`section`)");
  }
} catch (Throwable $e) { /* non-fatal */ }
