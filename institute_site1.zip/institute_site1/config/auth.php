<?php

define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin12345');
