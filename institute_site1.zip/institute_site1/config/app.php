<?php

$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$base = preg_replace('#/admin$#','', $scriptDir);
if ($base === '') { $base = '/'; }
define('BASE', $base);
