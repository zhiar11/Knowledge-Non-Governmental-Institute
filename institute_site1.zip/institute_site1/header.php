<?php

require_once __DIR__ . '/config/app.php';
?>
<!DOCTYPE html>
<html lang="ku" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>Knowledge Institute</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">


  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/style.css">

 
  <link rel="icon" type="image/png" href="<?php echo BASE; ?>/assets/img/logo.png">
</head>
<body>
<nav class="nav">
  <div class="inner">
    <div class="brand">
     
      <img src="<?php echo BASE; ?>/assets/img/logo.png"
           alt="Knowledge Institute logo">
      <div class="title">Knowledge Non-Governmental Institute</div>
    </div>

    <div class="menu">
      <a href="<?php echo BASE; ?>/index.php">ماڵەوە</a>
      <a href="<?php echo BASE; ?>/schedule.php">وانەکان</a>
      <a href="<?php echo BASE; ?>/news.php">هەواڵەکان</a>
      <a href="<?php echo BASE; ?>/departments.php">بەشەکان</a>
      <a href="<?php echo BASE; ?>/register.php">ناوتۆمارکردن</a>
      <a href="<?php echo BASE; ?>/location.php">ناونیشان</a>
      <a href="<?php echo BASE; ?>/contact.php">پەیوەندی</a>
      <a href="<?php echo BASE; ?>/about.php">زانیاری</a>
      <a href="<?php echo BASE; ?>/admin/login.php">ئادمین</a>
      <button id="themeToggle" class="theme-toggle" title="Toggle theme">🌙 Dark</button>
    </div>
  </div>
</nav>
