<?php
require __DIR__ . '/config/init.php';
$gallery = $pdo->query("SELECT * FROM gallery ORDER BY created_at DESC")->fetchAll();
include __DIR__ . '/header.php';
?>
<div class="container">
  <div class="card hero-mini"><h2>📷 ڕەنگاڵە و ڤیدیۆکان</h2></div>
  <div class="grid">
    <?php foreach ($gallery as $g): ?>
      <div class="card">
        <h3><?php echo htmlspecialchars($g['title']); ?></h3>
        <?php if ($g['type'] === 'video'): ?>
          <video controls width="100%" style="border-radius:12px;">
            <source src="uploads/<?php echo htmlspecialchars($g['file']); ?>">
          </video>
        <?php else: ?>
          <img src="uploads/<?php echo htmlspecialchars($g['file']); ?>" width="100%" style="border-radius:12px;">
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
