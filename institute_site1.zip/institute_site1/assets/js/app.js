(function () {
  const STORAGE_KEY = 'ki-theme';

  function applyTheme(theme) {
    const root = document.documentElement;

    if (theme !== 'light' && theme !== 'dark') {
      theme = 'dark';
    }

    root.setAttribute('data-theme', theme);

    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch (e) {}

    const btn = document.getElementById('themeToggle');
    if (btn) {
      btn.textContent = theme === 'light' ? '☀️ Light' : '🌙 Dark';
    }
  }

  function initTheme() {
    let theme = 'dark';

    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'light' || saved === 'dark') {
        theme = saved;
      } else if (
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: light)').matches
      ) {
        theme = 'light';
      }
    } catch (e) {}

    applyTheme(theme);

    const btn = document.getElementById('themeToggle');
    if (btn) {
      btn.addEventListener('click', function () {
        const current =
          document.documentElement.getAttribute('data-theme') === 'light'
            ? 'light'
            : 'dark';
        const next = current === 'light' ? 'dark' : 'light';
        applyTheme(next);
      });
    }


    const toTop = document.getElementById('toTop');
    if (toTop) {
      window.addEventListener('scroll', () => {
        toTop.style.display = window.scrollY > 300 ? 'flex' : 'none';
      });
      toTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  }

  document.addEventListener('DOMContentLoaded', initTheme);
})();