<?php require __DIR__ . '/config/init.php'; ?>
<?php
$ok=false; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name=trim($_POST['name']??'');
  $email=trim($_POST['email']??'');
  $phone=trim($_POST['phone']??'');
  $dept=trim($_POST['department']??'');
  if($name===''||$email===''||$phone===''){ $err='Please fill in name, email, and phone.'; }
  elseif(!filter_var($email,FILTER_VALIDATE_EMAIL)){ $err='Invalid email.'; }
  else{
    $stmt=$pdo->prepare("INSERT INTO registrations(full_name,email,phone,department) VALUES (?,?,?,?)");
    $stmt->execute([$name,$email,$phone,$dept]); $ok=true;
  }
}
include __DIR__ . '/header.php';
?>
<div class="container">
  <h2>ناونووسینی خوێندکار</h2>
  <?php if($ok): ?><div class="card">🎉 دەست خۆش، ناو تۆمارکردنتان وەرگیراوە.</div>
  <?php else: ?>
    <?php if($err): ?><div class="card" style="border-color:#80333b;background:#26151a;color:#ffd7de"><?php echo h($err); ?></div><?php endif; ?>
    <form method="post" class="card" style="display:grid;gap:10px;max-width:640px">
      <label>ناو <input required name="name" class="input" placeholder="Full name"></label>
      <label>ئیمەیل <input required type="email" name="email" class="input" placeholder="you@example.com"></label>
      <label>موبایل <input required name="phone" class="input" placeholder="+964 ..."></label>
      <label>بەش/لاق <input name="department" class="input" placeholder="Web / 4 / 5, Pro / 1, Computer 3 ..."></label>
      <button class="btn" type="submit">ناردن</button>
    </form>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/footer.php'; ?>
