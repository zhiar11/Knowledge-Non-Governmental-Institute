<?php require __DIR__ . '/config/init.php'; ?>
<?php include __DIR__ . '/header.php'; ?>
<div class="container">
  <h2>ناونیشان</h2>
  <div class="columns">
    <div class="card">
      <h3>ماپ</h3>
      <div style="aspect-ratio:16/9;background:#0e1430;border:1px solid var(--stroke);border-radius:14px;overflow:hidden">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31941.55446898103!2d45.8588565712805!3d35.3597149318974!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3fff15a471570c97%3A0xd30b8cbef39f8650!2sKnowledge%20institute%20in%20said%20sadq!5e1!3m2!1sen!2siq!4v1761706480597!5m2!1sen!2siq"
          style="border:0;width:100%;height:100%;" allowfullscreen="" loading="lazy"></iframe>
      </div>
    </div>
    <div class="card">
      <h3>ئادرێس</h3>
      <p> Iraq, Kurdistan,Slimani, SaidSadq</p>
  
      
    </div>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
