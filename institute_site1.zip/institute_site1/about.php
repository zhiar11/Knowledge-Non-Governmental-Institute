<?php require __DIR__ . '/config/init.php'; ?>
<?php include __DIR__ . '/header.php'; ?>
 <html lang="ku" dir="rtl">
<div class="container">
  <h2>سەبارەت بە پەیمانگا</h2>
  <div class="columns">
    <div class="card"><h3>ئەرکی ئێمە</h3><p> کوردی: <br> <br>(Knowledge Institute) پەیمانگای نۆلج  لە ساڵی 2021 دامەزراوە پەیمانگایەکی ناحوکمییە کە لە ژێر چاودێری و رێنمایی وزارەتی خوێندنی باڵای هەرێمی کوردستان کاردەکات.
ئەم پەیمانگایە دامەزرابووە بە مەبەستی پەرەسەندن و بەرزکردنەوەی ئاستی زانستی و تەکنەلۆژیای خوێندکاران، و دابینکردنی کادەری شارەزا بۆ بازارى کار.

پەیمانگاکە هەندێک بەش و کۆلێژی گرنگی تێدایە وەک: <br>
 • بەشی کۆمپیوتەر    <br>
 • بەشی کارکێڕی     <br>
 • بەشی نەوت          <br>

پەیمانگای نۆلج سیستەمی نوێی خوێندن بەکاردێنێت و وانەکان بە زمانەکانی کوردی و ئینگلیزی دەدرێنەوە.
هەروەها پەیمانگاکە هەوڵدەدات پەیوەندی و هاوکاری زانستی لەگەل زانکۆ و پەیمانگاکانی ناوخۆ و دەرەوە پەیوەست بکات.
<br> 
<br>
English:
<br>
<br>
Knowledge Institute is a non-governmental academic institute operating under the supervision of the Ministry of Higher Education and Scientific Research of the Kurdistan Region.
It was established to improve the academic and technological level of students and to prepare qualified graduates for the labor market.

The institute includes several important departments such as:
 • Computer Department
 • Administration Department
 • Petroleum Department

Knowledge Institute applies a modern educational system, and lectures are delivered in Kurdish and English.
The institute also strives to build academic cooperation with national and international universities and institutes.
</p><h3></h3><ul></ul></div>
    <div class="card"><h3>بۆچی ئێمە هەڵدەبژێری؟</h3><ul><li>کوردی: <br>
  <br>• پەیمانگاکە خوێندکار دەپارێزێت بۆ داهاتووی کار و ژیانی تەکنەلۆجیا.
  <br>• داهێنانی سیستەمی خوێندنی نوێی بەرەوپێش و ڕێنوێنی زانستی.
  <br>• ئامراز و کارەبەری تایبەتی بۆ هەموو بەشەکان دابین کراوە.
  <br>• ڕەفتارێکی دوستانە و پەیوەندی نزیک لە نێوان مامۆستا و خوێندکاران.
  <br>• پەیمانگاکە بەشی کۆمپیوتەر، نەوت و کارکێڕی تێدایە، کە هەموویان پەیوەندیدارن بە بازاڕی کار.
  <br>• ئەنجامدانی پڕۆژە و تاقیکردنەوەکانی کاربەری بۆ زیادکردنی توانای خوێندکاران.
  <br>• ئامانجی سەرەکی پەیمانگا ئەوەیە کە خوێندکارێکی بەهێز و شارەزا پێشکەش بکات بە کۆمەڵگە.
<br>
<br>
English: <br>
<br>
 • The institute prepares students for the future of technology and professional life. <br>
 • It applies a modern, research-oriented educational system. <br>
 • Equipped with specialized labs and facilities for all departments. <br>
 • Provides a friendly and supportive relationship between teachers and students. <br>
 • Offers Computer, Petroleum, and Administration departments, all relevant to today’s job market. <br>
 • Encourages practical projects and experiments to enhance students’ real skills. <br>
 • Our main goal is to graduate skilled, confident, and creative students ready to serve society.</div>
  </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
