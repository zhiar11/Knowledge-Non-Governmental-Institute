<?php

$SERVER_NAME = "localhost";
 $USERNAME ="root";
$password ="";
$DATABASE ="database";
$conn=mysqli_connect($SERVER_NAME , $USERNAME ,$password,$DATABASE );
if($conn->connect_error){
    die("connection fail".$sol->connect_error);

}
echo "";


?>